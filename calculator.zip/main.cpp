#include <iostream>
#include <stack>
#include <cmath>
#include <string>

using namespace std;

// Функция для выполнения операций (+, -, *, /, ^, s, r, a)
int calculate(char op, double left, double right = 0) {
    if (op == '+')
        return left + right;
    else if (op == '-')
        return left - right;
    else if (op == '*')
        return left * right;
    else if (op == '/') {
        if (right != 0)
            return left / right;
        else {
            cout << "Error: Division by zero!" << endl;
            return 0;
        }
    }
    else if (op == '^')
        return pow(left, right);
    else if (op == 's')
        return sqrt(left);
    else if (op == 'r')
        return round(left);
    else if (op == 'a')
        return abs(left);
    return 0;
}

// Функция для определения приоритета оператора
int pri(char op) {
    if (op == '^' || op == 'r' || op == 's' || op == 'a') // Наивысший приоритет для операторов возведения в степень, округления, квадратного корня и модуля
        return 3;
    else if (op == '*' || op == '/') // Средний приоритет для умножения и деления
        return 2;
    else if (op == '+' || op == '-') // Наименьший приоритет для сложения и вычитания
        return 1;
    return -1; // Если символ не является оператором
}

int main() {
    string math;
    cout << "Enter a mathematical expression: ";
    getline(cin, math);

    stack<char> s; // Стек для операторов
    stack<double> op_s; // Стек чисел
    double number = 0;
    double decimalPlace = 10;

    // Проход по каждому символу в математическом выражении
    for (auto i = 0; i < math.size(); i++) {
        if (isdigit(math[i])) {
            number = number * 10 + (math[i] - '0'); // Формирование числа из цифр
        }
        else if (math[i] == '.') {
            i++;
            // Обработка десятичной части числа
            while (i < math.size() && isdigit(math[i])) {
                number += (math[i] - '0') / decimalPlace;
                decimalPlace *= 10;
                i++;
            }
            i--;
        }
        else if (math[i] == '(') {
            s.push('('); // Если символ - открывающая скобка, помещаем ее в стек операторов
        }
        else if (math[i] == ')') {
            op_s.push(number); // Закончилось число, помещаем его в стек чисел
            number = 0; 
            decimalPlace = 10; 
            // Обработка выражений в скобках
            while (s.top() != '(') {
                double r = op_s.top();
                op_s.pop();
                double l = op_s.top();
                op_s.pop();
                double re = calculate(s.top(), l, r); // Выполнение операции
                op_s.push(re); // Результат помещается обратно в стек чисел
                s.pop();
            }
            s.pop(); // Удаляем '(' из стека операторов
        }
        else if (math[i] == '+' || math[i] == '-' || math[i] == '*' || math[i] == '/' || math[i] == '^' || math[i] == 's' || math[i] == 'r' || math[i] == 'a') {
            op_s.push(number); // полученное число, помещаем его в стек чисел
            number = 0; 
            decimalPlace = 10;

            int pC = pri(math[i]); // Определение приоритета текущего оператора
            // Обработка операторов в зависимости от их приоритета
            while (!s.empty() && pri(s.top()) >= pC) {
                double r = op_s.top();
                op_s.pop();
                double l = op_s.top();
                op_s.pop();
                double re = calculate(s.top(), l, r); // Выполнение операции
                op_s.push(re); // Результат помещается обратно в стек числами
                s.pop();
            }
            s.push(math[i]); // Помещаем текущий оператор в стек операторов
        }
    }

    op_s.push(number); // Помещаем последнее число в стек чисел
    // Выполнение оставшихся операций в стеке операторов
    while (!s.empty()) {
        double r = op_s.top();
        op_s.pop();
        double l = op_s.top();
        op_s.pop();
        double re = calculate(s.top(), l, r); // Выполнение операции
        op_s.push(re); // Результат помещается обратно в стек чисел
        s.pop();
    }

    cout << "Result: " << op_s.top() << endl; 

    return 0;
}